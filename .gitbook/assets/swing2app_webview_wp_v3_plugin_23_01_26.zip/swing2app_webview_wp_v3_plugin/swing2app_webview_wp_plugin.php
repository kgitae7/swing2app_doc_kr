<?php

/*
  Plugin Name: Swing2App WebView Plugin
  Plugin URI: https://www.swing2app.com
  Description: Swing2App WebView User integration Plugin
  Version: 0.1
  Author: Justin Kim
  Author URI: https://www.swing2app.com
 */


function swing2app_webview_wp_activation() {
    /*
      Plugin Activation Function
      - Plugin의 Data 저장을 위한 DB Table 생성
      - Custom Option의 생성
      - Dependent Plugin들의 Validation
      - 기타 ...
    */
}
register_activation_hook(__FILE__, 'swing2app_webview_wp_activation');


function swing2app_webview_wp_deactivation() {
    /*
      Plugin Deactivation Function
      - DB Table 삭제
      - Custom Option Reset
      - 기타 ...
    */
}
function swing_login_header() {
  if (is_user_logged_in()) {
?>
    <script>
			console.log('logged in');
		</script>
		<script src="https://pcdn2.swing2app.co.kr/swing_public_src/v3/2023_01_16_001/js/swing_app_on_web.js"></script>

		<script>
		swingWebViewPlugin.app.login.doAppLogin('<?php echo wp_get_current_user()->user_login;?>','<?php echo wp_get_current_user()->display_name;?>');
		</script>
    <?php
    	}
    	else{
    ?>
    	<script>
    			console.log("logged out");
    	</script>
    	<script src="https://pcdn2.swing2app.co.kr/swing_public_src/v3/2023_01_16_001/js/swing_app_on_web.js"></script>
    	swingWebViewPlugin.app.login.doAppLogout();
    	</script>
    <?php
    	}
    }
add_action('wp_head','swing_login_header');
?>
<?php
register_deactivation_hook(__FILE__, 'swing2app_webview_wp_deactivation');
?>
